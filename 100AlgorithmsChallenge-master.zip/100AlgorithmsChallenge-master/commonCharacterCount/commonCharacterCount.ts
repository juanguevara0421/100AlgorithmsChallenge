function commonCharacterCount(s1: string, s2: string): number {
   
}

console.log(commonCharacterCount('aabcc', 'adcaa'));