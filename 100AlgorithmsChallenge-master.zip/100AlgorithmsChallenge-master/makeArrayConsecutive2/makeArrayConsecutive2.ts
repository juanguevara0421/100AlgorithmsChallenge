function makeArrayConsecutive2(statues: number[]): number {

}

console.log(makeArrayConsecutive2([6, 2, 3, 8]));