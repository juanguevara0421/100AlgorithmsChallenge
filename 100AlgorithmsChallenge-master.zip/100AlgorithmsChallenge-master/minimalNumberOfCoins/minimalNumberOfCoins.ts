function minimalNumberOfCoins(coins: number[], price: number): number {

}

console.log(minimalNumberOfCoins([1, 2, 10], 28));