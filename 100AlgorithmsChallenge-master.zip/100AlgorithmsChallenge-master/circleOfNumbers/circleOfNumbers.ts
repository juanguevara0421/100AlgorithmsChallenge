function circleOfNumbers(n: number, firstNumber: number): number {

}

console.log(circleOfNumbers(10, 2));