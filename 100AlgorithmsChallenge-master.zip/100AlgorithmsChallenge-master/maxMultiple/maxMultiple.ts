function maxMultiple(divisor: number, bound: number): number  {

}

console.log(maxMultiple(3,10));