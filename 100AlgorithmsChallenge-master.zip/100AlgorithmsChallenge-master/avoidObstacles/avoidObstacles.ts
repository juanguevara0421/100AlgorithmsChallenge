function avoidObstacles(inputArray: number[]): number {

}

console.log(avoidObstacles([5, 3, 6, 7, 9]));