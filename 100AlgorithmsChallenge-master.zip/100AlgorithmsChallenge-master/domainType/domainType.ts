function domainType(domains: string[]): string[] {

}

console.log(domainType(["en.wiki.org", "codefights.com", "happy.net", "code.info"]));