### Check Out My [YouTube Channel](https://www.YouTube.com/CodingTutorials360)

### Check Out More Algorithms like this at <a href="https://www.FreeCodeCamp.com"> FreeCodeCamp</a>
---
You will be provided with an initial array (the first argument in the destroyer function), followed by one or more arguments. Remove all elements from the initial array that are of the same value as these arguments.

**Example**
-   seekAndDestroy([3, 5, 1, 2, 2], [2, 3, 5]) should return [1]
-   seekAndDestroy([1, 2, 3, 5, 1, 2, 3], [2, 3]) should return [1, 5, 1]

**Hints**
-   filter()
-   includes()