function squareDigitsSequence(a0: number): number {

}


console.log(squareDigitsSequence(16));
console.log(squareDigitsSequence(103));