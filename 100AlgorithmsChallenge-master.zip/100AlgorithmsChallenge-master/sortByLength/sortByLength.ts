function sortByLength(inputArray: string[]): string[] {

}

console.log(sortByLength(["abc",
"",
"aaa",
"a",
"zz"]));