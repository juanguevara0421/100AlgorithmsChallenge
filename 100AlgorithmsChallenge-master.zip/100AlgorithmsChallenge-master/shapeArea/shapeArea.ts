function shapeArea(n: number): number {

}

console.log(shapeArea(2));
console.log(shapeArea(3));