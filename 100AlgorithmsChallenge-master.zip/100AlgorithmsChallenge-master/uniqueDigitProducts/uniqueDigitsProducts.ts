function uniqueDigitProducts(a: number[]): number {
}

console.log(uniqueDigitProducts([2, 8, 121, 42, 222, 23]));