function stolenLunch(note: string): string {

}

console.log(stolenLunch("you'll n4v4r 6u4ss 8t: cdja"));