function pagesNumberingWithInk(current: number, numberOfDigits: number): number {

}
