function properNounCorrection(noun: string): string {
   
}

console.log(properNounCorrection('pARiS'));
console.log(properNounCorrection('John'));