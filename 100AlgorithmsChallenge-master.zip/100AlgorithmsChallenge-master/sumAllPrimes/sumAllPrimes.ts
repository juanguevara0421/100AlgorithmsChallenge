function sumAllPrimes(num: number): number {

}

console.log(sumAllPrimes(10));
console.log(sumAllPrimes(977));