function fermactor(n: number): number[] {

}

console.log(fermactor(15));