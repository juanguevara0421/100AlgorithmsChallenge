function sumOfTwo(a: number[], b: number[], v: number): boolean {

}

console.log(sumOfTwo([1, 2, 3], [10, 20, 30, 40], 42));