function alphabeticShift(inputString: string): string {

}

console.log(alphabeticShift('crazy'));