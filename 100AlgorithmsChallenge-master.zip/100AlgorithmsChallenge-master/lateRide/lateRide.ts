function lateRide(n: number): number {

}

console.log(lateRide(240));
console.log(lateRide(808));
