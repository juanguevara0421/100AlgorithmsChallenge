function boxBlur(image: number[][]): number[][] {

}

console.log(boxBlur([[1, 1, 1], 
    [1, 7, 1], 
    [1, 1, 1]]));