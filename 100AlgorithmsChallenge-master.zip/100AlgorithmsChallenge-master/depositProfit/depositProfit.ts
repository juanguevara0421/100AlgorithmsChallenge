function depositProfit(deposit: number, rate: number, threshold: number): number {
 
}

console.log(depositProfit(100, 20, 170))