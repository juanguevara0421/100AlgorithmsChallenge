function addBorder(picture: string[]): string[] {

}

// console.log(addBorder(["abc", "ded"]));