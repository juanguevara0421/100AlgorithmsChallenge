function almostIncreasingSequence(sequence: number[]): boolean {

}

// console.log(almostIncreasingSequence([1, 3, 2, 1])) 
// console.log(almostIncreasingSequence([1, 3, 2])) 