function adjacentElementsProduct(inputArray: number[]): number {

}

//console.log(adjacentElementsProduct([3, 6, -2, -5, 7, 3]));