function houseOfCats(legs: number): number[] {

}

console.log(houseOfCats(6));
console.log(houseOfCats(2));
