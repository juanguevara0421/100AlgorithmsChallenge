function chessBoardCellColor(cell1: string, cell2: string): boolean {

}

console.log(chessBoardCellColor('A1', 'C3'));
console.log(chessBoardCellColor('A1', 'H3'));
