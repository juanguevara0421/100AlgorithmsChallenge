function candies(n: number, m: number): number {

}

console.log(candies(3, 10));