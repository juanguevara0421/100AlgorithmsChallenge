function switchLights(a: number[]): number[] {

}


console.log(switchLights([1, 1, 1, 1, 1]));
console.log(switchLights([0, 0]));