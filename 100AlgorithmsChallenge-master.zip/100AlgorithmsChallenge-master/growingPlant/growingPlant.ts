function growingPlant(upSpeed: number, downSpeed: number, desiredHeight: number): number {

}

console.log(growingPlant(100, 10, 910))