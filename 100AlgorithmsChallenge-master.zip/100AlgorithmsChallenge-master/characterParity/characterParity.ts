function characterParity(symbol: string): string {
   
}

console.log(characterParity('5'))
console.log(characterParity('8'))
console.log(characterParity('q'))
