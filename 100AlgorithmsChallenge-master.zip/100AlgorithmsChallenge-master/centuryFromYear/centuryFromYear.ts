function centuryFromYear(year: number): number {
 
}

console.log(centuryFromYear(1905));
console.log(centuryFromYear(1700));