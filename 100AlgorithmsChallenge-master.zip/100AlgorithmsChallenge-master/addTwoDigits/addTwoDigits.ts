function addTwoDigits(n: any): number {

}

// console.log(addTwoDigits(29));