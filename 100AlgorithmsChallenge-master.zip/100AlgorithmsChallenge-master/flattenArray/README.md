### Check Out My [YouTube Channel](https://learn.freecodecamp.org/javascript-algorithms-and-data-structures/intermediate-algorithm-scripting/steamroller)

---
Flatten a nested array. You must account for varying levels of nesting.

**Example**

-   steamrollArray([[["a"]], [["b"]]]) should return ["a", "b"].

-   steamrollArray([1, [2], [3, [[4]]]]) should return [1, 2, 3, 4]

**Hints**
-   isArray()
-   push()