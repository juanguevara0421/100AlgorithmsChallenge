function containsDuplicates(a: number[]): boolean {

}

console.log(containsDuplicates([1, 2, 3, 1]));
console.log(containsDuplicates([3, 1]));
